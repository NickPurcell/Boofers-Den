Clawd crab robot (v2): single-leg test rig
https://boofers-den.vercel.app/sections/guitar-goblin/clawd-bot/#rig

clawd-rig-*.stl    printed parts, laid out for the bed (Z up). No supports needed.
clawd_leg_rig.scad parametric source (OpenSCAD 2021+). Fits and MG90S dimensions are at the top.
                   openscad -D 'part="carriage"' -o carriage.stl clawd_leg_rig.scad
                   part = base | column | carriage | leg | crank | assembly; mode = "rig" for rig coordinates.
clawd_leg_rig.ino  test sketch for one leg (ESP32 + PCA9685 channels 0/1, or ESP32Servo on pins 18/19).
clawd_bot.ino      the full robot sketch, same gait tables.
check.py           the manifold and clearance checks (trimesh + manifold3d), run on the "rig" mode exports;
check.json         their results. poses.json: the 324 leg poses the gaits and test sweeps use.

Print: PLA (PETG for the carriage and crank if you like), 3-4 walls; see the page for per-part settings.
Hardware for one leg: 2x MG90S, 2x 3 mm steel rod 65 mm, 2x LM3UU, 1x M2x10 screw (yoke pin),
4x M2 self-tappers (servo tabs), 3x M3x12 + nuts, bench screws or a clamp.
