// Clawd crab robot (v2): 8 servos, all inside the shell, on a PCA9685 driven by an ESP32.
// Printed from the same gait tables as the 3D sim at
// https://boofers-den.vercel.app/sections/guitar-goblin/clawd-bot/
//
// Each rigid leg hangs from a swing servo (foot forward and back). The swing servo rides on a carriage that slides
// up and down two rods; the lift servo moves the carriage through a Scotch yoke (a pin on its horn in a slot).
//
// Library: "Adafruit PWM Servo Driver Library" (Arduino Library Manager). Board: "ESP32 Dev Module".
// Wiring: PCA9685 SDA -> GPIO21, SCL -> GPIO22, VCC -> 3V3, GND -> GND. Servo power (V+) from the 6 V buck.
// Serial monitor at 115200 baud, one letter at a time:
//   w = walk / stop   c = creep   t = trot   a = turn left   d = turn right   s = straight   + / - = speed

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca(0x40);

// Channels: 0 LF swing, 1 LF lift, 2 RF swing, 3 RF lift, 4 LH swing, 5 LH lift, 6 RH swing, 7 RH lift.
// Servo angle = 90 + DIR * joint angle. Swing: + = foot forward. Lift: + = carriage up (horn above level).
const int8_t SWING_DIR[4] = { 1, -1, 1, -1 };
const int8_t LIFT_DIR[4]  = { -1, 1, 1, -1 };
int8_t TRIM[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };  // calibration, degrees: make the first keyframe stand level
const uint16_t US_MIN = 500, US_MAX = 2500;    // pulse for 0 and 180 degrees; check your servos' range

// Leg geometry in mm (must match the build): swing axis to sole, lift horn radius, lift shaft height, step height.
const float LEG = 56, CRANK = 16, YOKE_Y = 61, LIFT_MM = 14, DOWN_MM = 0.5;

// Joint angles in degrees: one row per keyframe, columns in channel order.
const int8_t CREEP[20][8] = {
  {   5, -19,  23, -37,  -5, -19,  14, -24 },
  {  -5, -19,  14, -24, -14, -24,   5, -19 },
  { -14, -24,   5, -19, -23, -37,  -5, -19 },
  { -20, -32,  -2, -18, -17,  17, -11, -22 },
  { -22, -35,  -4, -19,  -7,  25, -13, -23 },
  { -19, -31,  -1, -18,   8, -20, -10, -21 },
  { -14, -24,   5, -19,  14, -24,  -5, -19 },
  {  -8, -20,  10, -21,  19, -31,   1, -18 },
  {   7,  25,  13, -23,  22, -35,   4, -19 },
  {  17,  17,  11, -22,  20, -32,   2, -18 },
  {  23, -37,   5, -19,  14, -24,  -5, -19 },
  {  14, -24,  -5, -19,   5, -19, -14, -24 },
  {   5, -19, -14, -24,  -5, -19, -23, -37 },
  {  -2, -18, -20, -32, -11, -22, -17,  17 },
  {  -4, -19, -22, -35, -13, -23,  -7,  25 },
  {  -1, -18, -19, -31, -10, -21,   8, -20 },
  {   5, -19, -14, -24,  -5, -19,  14, -24 },
  {  10, -21,  -8, -20,   1, -18,  19, -31 },
  {  13, -23,   7,  25,   4, -19,  22, -35 },
  {  11, -22,  17,  17,   2, -18,  20, -32 },
};
const int8_t TROT[8][8] = {
  {  16, -26, -16, -26, -16, -26,  16, -26 },
  {   8, -20,  -8,  16,  -8,  16,   8, -20 },
  {   0, -18,   0,  34,   0,  34,   0, -18 },
  {  -8, -20,   8,  16,   8,  16,  -8, -20 },
  { -16, -26,  16, -26,  16, -26, -16, -26 },
  {  -8,  16,   8, -20,   8, -20,  -8,  16 },
  {   0,  34,   0, -18,   0, -18,   0,  34 },
  {   8,  16,  -8, -20,  -8, -20,   8,  16 },
};

struct Gait { const int8_t (*table)[8]; uint8_t frames; float duty; float offset[4]; uint16_t frameMs; };
const Gait GAITS[2] = {
  { CREEP, 20, 0.85f, { 0.5f, 0.0f, 0.75f, 0.25f }, 100 },
  { TROT ,  8, 0.5f, { 0.0f, 0.5f, 0.5f, 0.0f }, 100 },
};
const uint8_t SWING_ORDER[4] = { 2, 0, 3, 1 };  // LH, LF, RH, RF
const uint16_t STEP_MS = 150;                    // per half-step while re-planting feet

uint8_t gait = 0;               // 0 = creep, 1 = trot
int8_t nextGait = -1;           // gait change waiting for all four feet to be down
float f = 0;                    // position in the gait, in keyframes
float k[4] = { 1, 1, 1, 1 };    // per-leg stride scale, for turning
float turn = 0, turnTarget = 0; // -1..1, + = right
float speed = 1;
bool walking = false;
uint32_t last = 0;

void writeJoint(uint8_t ch, float deg) {
  int8_t dir = (ch % 2 == 0) ? SWING_DIR[ch / 2] : LIFT_DIR[ch / 2];
  float a = constrain(90 + dir * deg + TRIM[ch], 0.0f, 180.0f);
  pca.writeMicroseconds(ch, US_MIN + (uint16_t)(a * (US_MAX - US_MIN) / 180.0f));
}

void writeAll(const float *a) {
  for (uint8_t ch = 0; ch < 8; ch++) writeJoint(ch, a[ch]);
}

// Foot height for a swing and lift angle, and the lift angle that puts the foot at height y.
float footY(float swing, float lift) {
  return YOKE_Y + CRANK * sinf(lift * DEG_TO_RAD) - LEG * cosf(swing * DEG_TO_RAD);
}
float liftFor(float swing, float y) {
  return asinf(constrain((y + LEG * cosf(swing * DEG_TO_RAD) - YOKE_Y) / CRANK, -1.0f, 1.0f)) * RAD_TO_DEG;
}

void sideScale(float t, float &kl, float &kr) {  // each side's stride while turning (skid steering)
  kl = 1 + t; kr = 1 - t;
  float m = max(1.0f, max(fabsf(kl), fabsf(kr)));
  kl /= m; kr /= m;
}

void anglesAt(const Gait &g, float pos, float *out) {  // linear between keyframes
  uint8_t k0 = (uint8_t)pos % g.frames, k1 = (k0 + 1) % g.frames;
  float a = pos - floorf(pos);
  for (uint8_t i = 0; i < 4; i++) {
    float s = g.table[k0][2 * i] * (1 - a) + g.table[k1][2 * i] * a;
    float l = g.table[k0][2 * i + 1] * (1 - a) + g.table[k1][2 * i + 1] * a;
    if (k[i] == 1) { out[2 * i] = s; out[2 * i + 1] = l; continue; }
    out[2 * i] = s * k[i];
    out[2 * i + 1] = liftFor(s * k[i], footY(s, l));  // shorter step, same foot height
  }
}

float swingAt(const Gait &g, float pos, uint8_t i) {  // 0..1 while foot i is in the air, -1 while it is down
  float p = fmodf(pos / g.frames + g.offset[i], 1.0f);
  return p >= g.duty ? (p - g.duty) / (1 - g.duty) : -1;
}

bool allDown(const Gait &g, uint8_t row) {
  for (uint8_t i = 0; i < 4; i++) if (footY(g.table[row][2 * i], g.table[row][2 * i + 1]) >= DOWN_MM) return false;
  return true;
}

void glide(const float *a, const float *b) {
  uint16_t ms = STEP_MS / speed;
  for (uint16_t t = 20; t <= ms; t += 20) {
    float s = t / (float)ms, p[8];
    for (uint8_t j = 0; j < 8; j++) p[j] = a[j] * (1 - s) + b[j] * s;
    writeAll(p);
    delay(20);
  }
}

// Gait change: move the feet one at a time (lift, swing, put down) to the new gait's first keyframe.
void replant(uint8_t to) {
  float cur[8], target[8], mid[8];
  anglesAt(GAITS[gait], f, cur);
  gait = to; f = 0;
  anglesAt(GAITS[gait], 0, target);
  for (uint8_t n = 0; n < 4; n++) {
    uint8_t i = SWING_ORDER[n];
    if (fabsf(cur[2 * i] - target[2 * i]) < 0.5f) continue;
    memcpy(mid, cur, sizeof mid);
    mid[2 * i] = (cur[2 * i] + target[2 * i]) / 2;
    mid[2 * i + 1] = liftFor(mid[2 * i], LIFT_MM);
    glide(cur, mid);
    cur[2 * i] = target[2 * i];
    cur[2 * i + 1] = target[2 * i + 1];
    glide(mid, cur);
  }
}

void step(float ms) {
  const Gait &g = GAITS[gait];
  float f0 = f, f1 = f0 + ms / g.frameMs;
  float kl, kr;
  sideScale(turn, kl, kr);
  // A new turn value reaches a leg only while it is in the air, so feet on the ground are never dragged.
  for (uint8_t i = 0; i < 4; i++) {
    float s0 = swingAt(g, f0, i), s1 = swingAt(g, fmodf(f1, g.frames), i);
    float target = (i == 0 || i == 2) ? kl : kr;  // legs 0 and 2 are on the left
    if (s0 >= 0 && s1 < 0) k[i] = target;
    else if (s0 >= 0 && s1 > s0) k[i] += (target - k[i]) * min(1.0f, (s1 - s0) / (1 - s0));
  }
  if (nextGait >= 0) {
    for (int kf = (int)floorf(f0) + 1; kf <= f1; kf++) {
      if (allDown(g, kf % g.frames)) {
        f = kf % g.frames;
        uint8_t to = nextGait;
        nextGait = -1;
        replant(to);
        return;
      }
    }
  }
  f = fmodf(f1, g.frames);
}

void readSerial() {
  while (Serial.available()) {
    switch (Serial.read()) {
      case 'w': walking = !walking; break;
      case 'c': nextGait = (gait == 0) ? -1 : 0; break;
      case 't': nextGait = (gait == 1) ? -1 : 1; break;
      case 'a': turnTarget = -0.6f; break;
      case 'd': turnTarget = 0.6f; break;
      case 's': turnTarget = 0; break;
      case '+': speed = min(2.0f, speed + 0.25f); break;
      case '-': speed = max(0.25f, speed - 0.25f); break;
    }
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  pca.begin();
  pca.setOscillatorFrequency(27000000);
  pca.setPWMFreq(50);
  delay(10);
  // Soft start: wake the servos one at a time (lifts first, they carry the weight), so eight stall currents
  // never hit the battery at once.
  float a[8];
  anglesAt(GAITS[gait], 0, a);
  for (uint8_t ch = 1; ch < 8; ch += 2) { writeJoint(ch, a[ch]); delay(150); }
  for (uint8_t ch = 0; ch < 8; ch += 2) { writeJoint(ch, a[ch]); delay(150); }
  last = millis();
  Serial.println(F("Clawd ready. w = walk/stop, c = creep, t = trot, a/d/s = left/right/straight, +/- = speed"));
}

void loop() {
  readSerial();
  uint32_t now = millis();
  if (now - last < 20) return;  // 50 updates a second, the servo pulse rate
  float ms = (now - last) * speed;
  last = now;
  if (!walking) return;
  turn += constrain(turnTarget - turn, -ms / 600, ms / 600);
  step(ms);
  float a[8];
  anglesAt(GAITS[gait], f, a);
  writeAll(a);
}
